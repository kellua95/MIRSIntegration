﻿function assign(employee) {
    alert("تم تعيين الشكوى إلى " + employee);
}
